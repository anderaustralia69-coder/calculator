import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { TaxForm } from "./TaxForm";
import { TaxResults } from "./TaxResults";
import { CalculationHistory } from "./CalculationHistory";
import { Id } from "../../convex/_generated/dataModel";

export interface TaxData {
  country: string;
  fiscalYear: number;
  regime: string;
  currency: string;
  monthlyIncome: number;
  additionalIncome: number;
  bonuses: number;
  deductions: {
    medical: number;
    education: number;
    housing: number;
    donations: number;
    other: number;
  };
  retentions: number;
  maritalStatus: string;
  dependents: number;
  name?: string;
}

export interface TaxResults {
  totalIncome: number;
  totalDeductions: number;
  taxableBase: number;
  calculatedTax: number;
  netIncome: number;
  difference: number;
  taxRate: number;
}

export function TaxCalculator() {
  const [activeTab, setActiveTab] = useState<'calculator' | 'history'>('calculator');
  const [taxData, setTaxData] = useState<TaxData>({
    country: 'MX',
    fiscalYear: 2024,
    regime: 'Asalariado',
    currency: 'MXN',
    monthlyIncome: 0,
    additionalIncome: 0,
    bonuses: 0,
    deductions: {
      medical: 0,
      education: 0,
      housing: 0,
      donations: 0,
      other: 0,
    },
    retentions: 0,
    maritalStatus: 'single',
    dependents: 0,
  });
  
  const [results, setResults] = useState<TaxResults | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const countries = useQuery(api.taxCalculator.getCountries) || [];
  const calculateTax = useMutation(api.taxCalculator.calculateTax);

  // Load saved data from localStorage
  useEffect(() => {
    const savedData = localStorage.getItem('taxCalculatorData');
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData);
        setTaxData(prev => ({ ...prev, ...parsed }));
      } catch (error) {
        console.error('Error loading saved data:', error);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('taxCalculatorData', JSON.stringify(taxData));
  }, [taxData]);

  const handleCalculate = async () => {
    setIsCalculating(true);
    try {
      const result = await calculateTax(taxData);
      setResults(result.results);
      toast.success('Cálculo completado exitosamente');
    } catch (error) {
      toast.error('Error al calcular impuestos: ' + (error as Error).message);
    } finally {
      setIsCalculating(false);
    }
  };

  const handleReset = () => {
    setTaxData({
      country: 'MX',
      fiscalYear: 2024,
      regime: 'Asalariado',
      currency: 'MXN',
      monthlyIncome: 0,
      additionalIncome: 0,
      bonuses: 0,
      deductions: {
        medical: 0,
        education: 0,
        housing: 0,
        donations: 0,
        other: 0,
      },
      retentions: 0,
      maritalStatus: 'single',
      dependents: 0,
    });
    setResults(null);
    localStorage.removeItem('taxCalculatorData');
    toast.success('Formulario reiniciado');
  };

  return (
    <div className="space-y-6">
      {/* Navigation Tabs */}
      <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg w-fit mx-auto">
        <button
          onClick={() => setActiveTab('calculator')}
          className={`px-6 py-2 rounded-md font-medium transition-all ${
            activeTab === 'calculator'
              ? 'bg-white text-blue-600 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Calculadora
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-6 py-2 rounded-md font-medium transition-all ${
            activeTab === 'history'
              ? 'bg-white text-blue-600 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Historial
        </button>
      </div>

      {activeTab === 'calculator' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Tax Form */}
          <div className="space-y-6">
            <TaxForm
              taxData={taxData}
              setTaxData={setTaxData}
              countries={countries}
              onCalculate={handleCalculate}
              onReset={handleReset}
              isCalculating={isCalculating}
            />
          </div>

          {/* Tax Results */}
          <div className="space-y-6">
            <TaxResults
              results={results}
              taxData={taxData}
              isCalculating={isCalculating}
            />
          </div>
        </div>
      ) : (
        <CalculationHistory />
      )}
    </div>
  );
}
