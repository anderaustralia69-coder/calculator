import { mutation } from "./_generated/server";

export const seedInitialData = mutation({
  args: {},
  handler: async (ctx) => {
    // Check if data already exists
    const existingCountries = await ctx.db.query("countries").first();
    if (existingCountries) return;

    // Seed countries
    await ctx.db.insert("countries", {
      code: "MX",
      name: "México",
      currency: "MXN",
      currencySymbol: "$",
      regimes: ["Asalariado", "Honorarios", "Actividad Empresarial", "Arrendamiento"],
    });

    await ctx.db.insert("countries", {
      code: "US",
      name: "Estados Unidos",
      currency: "USD",
      currencySymbol: "$",
      regimes: ["Single", "Married Filing Jointly", "Married Filing Separately", "Head of Household"],
    });

    await ctx.db.insert("countries", {
      code: "ES",
      name: "España",
      currency: "EUR",
      currencySymbol: "€",
      regimes: ["Trabajo", "Actividades Económicas", "Capital Mobiliario", "Inmobiliario"],
    });

    // Seed Mexico tax brackets (2024)
    await ctx.db.insert("taxBrackets", {
      country: "MX",
      fiscalYear: 2024,
      regime: "Asalariado",
      brackets: [
        { min: 0, max: 125900, rate: 1.92, fixedAmount: 0 },
        { min: 125900, max: 1000000, rate: 6.4, fixedAmount: 2417 },
        { min: 1000000, max: 1750000, rate: 10.88, fixedAmount: 58245 },
        { min: 1750000, max: 2800000, rate: 16, fixedAmount: 139857 },
        { min: 2800000, max: 3500000, rate: 21.36, fixedAmount: 307857 },
        { min: 3500000, max: 4300000, rate: 23.52, fixedAmount: 457407 },
        { min: 4300000, rate: 30, fixedAmount: 645607 },
      ],
    });

    // Seed US tax brackets (2024)
    await ctx.db.insert("taxBrackets", {
      country: "US",
      fiscalYear: 2024,
      regime: "Single",
      brackets: [
        { min: 0, max: 11000, rate: 10, fixedAmount: 0 },
        { min: 11000, max: 44725, rate: 12, fixedAmount: 1100 },
        { min: 44725, max: 95375, rate: 22, fixedAmount: 5147 },
        { min: 95375, max: 182050, rate: 24, fixedAmount: 16290 },
        { min: 182050, max: 231250, rate: 32, fixedAmount: 37104 },
        { min: 231250, max: 578125, rate: 35, fixedAmount: 52832 },
        { min: 578125, rate: 37, fixedAmount: 174238 },
      ],
    });

    // Seed Spain tax brackets (2024)
    await ctx.db.insert("taxBrackets", {
      country: "ES",
      fiscalYear: 2024,
      regime: "Trabajo",
      brackets: [
        { min: 0, max: 12450, rate: 19, fixedAmount: 0 },
        { min: 12450, max: 20200, rate: 24, fixedAmount: 2365 },
        { min: 20200, max: 35200, rate: 30, fixedAmount: 4225 },
        { min: 35200, max: 60000, rate: 37, fixedAmount: 8725 },
        { min: 60000, max: 300000, rate: 45, fixedAmount: 17901 },
        { min: 300000, rate: 47, fixedAmount: 125901 },
      ],
    });
  },
});
