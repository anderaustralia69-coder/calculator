import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getCountries = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("countries").collect();
  },
});

export const getTaxBrackets = query({
  args: {
    country: v.string(),
    fiscalYear: v.number(),
    regime: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("taxBrackets")
      .withIndex("by_country_year_regime", (q) =>
        q.eq("country", args.country)
         .eq("fiscalYear", args.fiscalYear)
         .eq("regime", args.regime)
      )
      .first();
  },
});

export const calculateTax = mutation({
  args: {
    country: v.string(),
    fiscalYear: v.number(),
    regime: v.string(),
    currency: v.string(),
    monthlyIncome: v.number(),
    additionalIncome: v.number(),
    bonuses: v.number(),
    deductions: v.object({
      medical: v.number(),
      education: v.number(),
      housing: v.number(),
      donations: v.number(),
      other: v.number(),
    }),
    retentions: v.number(),
    maritalStatus: v.string(),
    dependents: v.number(),
    name: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    
    // Get tax brackets for calculation
    const taxBrackets = await ctx.db
      .query("taxBrackets")
      .withIndex("by_country_year_regime", (q) =>
        q.eq("country", args.country)
         .eq("fiscalYear", args.fiscalYear)
         .eq("regime", args.regime)
      )
      .first();

    if (!taxBrackets) {
      throw new Error("Tax brackets not found for the selected configuration");
    }

    // Calculate totals
    const annualIncome = (args.monthlyIncome * 12) + args.additionalIncome + args.bonuses;
    const totalDeductions = Object.values(args.deductions).reduce((sum, val) => sum + val, 0);
    const taxableBase = Math.max(0, annualIncome - totalDeductions);

    // Calculate progressive tax
    let calculatedTax = 0;
    let remainingIncome = taxableBase;

    for (const bracket of taxBrackets.brackets) {
      if (remainingIncome <= 0) break;

      const bracketMax = bracket.max || Infinity;
      const taxableInBracket = Math.min(remainingIncome, bracketMax - bracket.min);
      
      if (taxableInBracket > 0) {
        calculatedTax += bracket.fixedAmount + (taxableInBracket * bracket.rate / 100);
        remainingIncome -= taxableInBracket;
      }
    }

    const netIncome = annualIncome - calculatedTax;
    const difference = calculatedTax - args.retentions;
    const taxRate = annualIncome > 0 ? (calculatedTax / annualIncome) * 100 : 0;

    const results = {
      totalIncome: annualIncome,
      totalDeductions,
      taxableBase,
      calculatedTax,
      netIncome,
      difference,
      taxRate,
    };

    // Save calculation
    const calculationId = await ctx.db.insert("taxCalculations", {
      userId,
      ...args,
      results,
    });

    return { calculationId, results };
  },
});

export const getUserCalculations = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("taxCalculations")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(10);
  },
});

export const getCalculation = query({
  args: { id: v.id("taxCalculations") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.id);
  },
});

export const deleteCalculation = mutation({
  args: { id: v.id("taxCalculations") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    const calculation = await ctx.db.get(args.id);
    
    if (!calculation || calculation.userId !== userId) {
      throw new Error("Calculation not found or unauthorized");
    }

    await ctx.db.delete(args.id);
  },
});
