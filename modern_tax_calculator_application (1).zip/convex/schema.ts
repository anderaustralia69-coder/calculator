import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  taxCalculations: defineTable({
    userId: v.optional(v.id("users")),
    country: v.string(),
    fiscalYear: v.number(),
    regime: v.string(),
    currency: v.string(),
    monthlyIncome: v.number(),
    additionalIncome: v.number(),
    bonuses: v.number(),
    deductions: v.object({
      medical: v.number(),
      education: v.number(),
      housing: v.number(),
      donations: v.number(),
      other: v.number(),
    }),
    retentions: v.number(),
    maritalStatus: v.string(),
    dependents: v.number(),
    results: v.object({
      totalIncome: v.number(),
      totalDeductions: v.number(),
      taxableBase: v.number(),
      calculatedTax: v.number(),
      netIncome: v.number(),
      difference: v.number(),
      taxRate: v.number(),
    }),
    name: v.optional(v.string()),
  }).index("by_user", ["userId"]),

  taxBrackets: defineTable({
    country: v.string(),
    fiscalYear: v.number(),
    regime: v.string(),
    brackets: v.array(v.object({
      min: v.number(),
      max: v.optional(v.number()),
      rate: v.number(),
      fixedAmount: v.number(),
    })),
  }).index("by_country_year_regime", ["country", "fiscalYear", "regime"]),

  countries: defineTable({
    code: v.string(),
    name: v.string(),
    currency: v.string(),
    currencySymbol: v.string(),
    regimes: v.array(v.string()),
  }).index("by_code", ["code"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
